package com.ias_training.handyman;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HandymanApplicationTests {

	@Test
	void contextLoads() {
	}

}
